package co.cask.etl.plugin;

import co.cask.cdap.api.common.Bytes;
import co.cask.cdap.api.dataset.lib.KeyValueTable;
import co.cask.cdap.proto.AdapterConfig;
import co.cask.cdap.proto.Id;
import co.cask.cdap.template.etl.api.Transform;
import co.cask.cdap.template.etl.api.realtime.RealtimeSource;
import co.cask.cdap.template.etl.common.ETLStage;
import co.cask.cdap.template.etl.realtime.ETLRealtimeTemplate;
import co.cask.cdap.template.etl.realtime.config.ETLRealtimeConfig;
import co.cask.cdap.test.AdapterManager;
import co.cask.cdap.test.DataSetManager;
import co.cask.cdap.test.TestBase;
import co.cask.etl.plugin.sink.MockSink;
import co.cask.etl.plugin.source.MockSource;
import co.cask.etl.plugin.transform.TimestampFormatter;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.gson.Gson;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 */
public class EndToEndTest extends TestBase {
  private static final Gson GSON = new Gson();
  private static final Id.ApplicationTemplate TEMPLATE_ID = Id.ApplicationTemplate.from("ETLRealtime");

  @BeforeClass
  public static void setupTest() throws IOException {
    addTemplatePlugins(TEMPLATE_ID, "etl-mock-source-1.0.jar", MockSource.class);
    addTemplatePlugins(TEMPLATE_ID, "etl-mock-sink-1.0.jar", MockSink.class);
    // add the transform plugin jar
    addTemplatePlugins(TEMPLATE_ID, "etl-transform-plugins-1.0.jar", TimestampFormatter.class);
    // deploy the ETLBatch application template
    deployTemplate(Id.Namespace.DEFAULT, TEMPLATE_ID, ETLRealtimeTemplate.class,
      RealtimeSource.class.getPackage().getName(),
      Transform.class.getPackage().getName());
  }

  @Test
  public void testPlugin() throws Exception {
    // create the config for the pipeline
    // create the source part of the adapter config
    ETLStage source = new ETLStage("mock", ImmutableMap.of("ts", "1234567890000"));
    // create the sink part of the adapter config
    ETLStage sink = new ETLStage("mock", ImmutableMap.<String, String>of());
    // create the transform part of the adapter config
    ETLStage transform = new ETLStage("FormatTimestamp", ImmutableMap.<String, String>of());

    // create the entire adapter config
    ETLRealtimeConfig etlConfig = new ETLRealtimeConfig(source, sink, ImmutableList.of(transform));
    AdapterConfig adapterConfig = new AdapterConfig("description", TEMPLATE_ID.getId(), GSON.toJsonTree(etlConfig));

    // create the adapter with the given config
    Id.Adapter adapterId = Id.Adapter.from(Id.Namespace.DEFAULT, "timestampConverter");
    AdapterManager adapterManager = createAdapter(adapterId, adapterConfig);

    // start the adapter
    adapterManager.start();

    DataSetManager<KeyValueTable> tableManager = getDataset(MockSink.TABLE_NAME);
    // wait for the pipeline to write to the sink
    int retries = 0;
    byte[] dateBytes = tableManager.get().read("date");
    while (dateBytes == null && retries < 20) {
      TimeUnit.MILLISECONDS.sleep(100);
      tableManager.flush();
      dateBytes = tableManager.get().read("date");
      retries++;
    }
    // stop the adapter
    adapterManager.stop();

    // check that we didn't timeout
    Assert.assertTrue("Timed out waiting for data to be written", retries < 20);

    // check that the table has a new field with the date string
    String dateStr = Bytes.toString(dateBytes);
    Assert.assertEquals("2009-02-13T23:31:30.000", dateStr);
  }

}
