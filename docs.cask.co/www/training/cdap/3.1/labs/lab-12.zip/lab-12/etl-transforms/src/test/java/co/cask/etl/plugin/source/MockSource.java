package co.cask.etl.plugin.source;

import co.cask.cdap.api.annotation.Name;
import co.cask.cdap.api.annotation.Plugin;
import co.cask.cdap.api.common.Bytes;
import co.cask.cdap.api.data.format.StructuredRecord;
import co.cask.cdap.api.data.schema.Schema;
import co.cask.cdap.api.templates.plugins.PluginConfig;
import co.cask.cdap.template.etl.api.Emitter;
import co.cask.cdap.template.etl.api.realtime.RealtimeSource;
import co.cask.cdap.template.etl.api.realtime.SourceState;

import javax.annotation.Nullable;

/**
 * Mock realtime source for unit tests. Emits one record with a field "ts" that has whatever value is
 * set in the config.
 */
@Plugin(type = "source")
@Name("mock")
public class MockSource extends RealtimeSource<StructuredRecord> {
  private static final Schema schema = Schema.recordOf("mockRecord",
    Schema.Field.of("ts", Schema.of(Schema.Type.LONG)));
  private Config config;

  public static class Config extends PluginConfig {
    private long ts;
  }

  @Nullable
  @Override
  public SourceState poll(Emitter<StructuredRecord> writer, SourceState currentState) throws Exception {
    if (currentState.getState("emitted") == null) {
      writer.emit(StructuredRecord.builder(schema).set("ts", config.ts).build());
      currentState.setState("emitted", Bytes.toBytes(true));
    }
    return currentState;
  }
}
