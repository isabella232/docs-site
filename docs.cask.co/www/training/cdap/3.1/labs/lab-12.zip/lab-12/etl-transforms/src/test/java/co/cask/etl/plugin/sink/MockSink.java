package co.cask.etl.plugin.sink;

import co.cask.cdap.api.annotation.Name;
import co.cask.cdap.api.annotation.Plugin;
import co.cask.cdap.api.common.Bytes;
import co.cask.cdap.api.data.format.StructuredRecord;
import co.cask.cdap.api.dataset.DatasetProperties;
import co.cask.cdap.api.dataset.lib.KeyValueTable;
import co.cask.cdap.api.templates.plugins.PluginConfig;
import co.cask.cdap.template.etl.api.PipelineConfigurer;
import co.cask.cdap.template.etl.api.realtime.DataWriter;
import co.cask.cdap.template.etl.api.realtime.RealtimeSink;

import javax.annotation.Nullable;

/**
 * Mock sink for unit tests. Writes a field from records it gets to a KeyValue Table.
 */
@Plugin(type = "sink")
@Name("mock")
public class MockSink extends RealtimeSink<StructuredRecord> {
  public static final String TABLE_NAME = "mockOutput";
  private Config config;

  public static class Config extends PluginConfig {
    @Nullable
    private String field;

    private Config() {
      this.field = "date";
    }
  }

  @Override
  public int write(Iterable<StructuredRecord> objects, DataWriter dataWriter) throws Exception {
    int numWritten = 0;
    KeyValueTable table = dataWriter.getDataset(TABLE_NAME);
    for (StructuredRecord record : objects) {
      table.write(config.field, Bytes.toBytes((String) record.get(config.field)));
      numWritten++;
    }
    return numWritten;
  }

  @Override
  public void configurePipeline(PipelineConfigurer pipelineConfigurer) {
    pipelineConfigurer.createDataset(TABLE_NAME, KeyValueTable.class, DatasetProperties.EMPTY);
  }
}
