package co.cask.cdap.training.tickers;

import co.cask.cdap.api.metrics.RuntimeMetrics;
import co.cask.cdap.test.ApplicationManager;
import co.cask.cdap.test.DataSetManager;
import co.cask.cdap.test.FlowManager;
import co.cask.cdap.test.RuntimeStats;
import co.cask.cdap.test.StreamWriter;
import co.cask.cdap.test.TestBase;
import com.google.common.collect.ImmutableSet;
import com.google.gson.Gson;
import org.junit.Assert;
import org.junit.Test;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Tests the functioning of the Tickers flow.
 */
public class TickersTest extends TestBase {

  private static final Gson GSON = new Gson();

  private static final Session[] SESSIONS = {
    new Session("jim", ImmutableSet.of("GOOG", "YHOO", "FB")),
    new Session("tom", ImmutableSet.of("GOOG", "EBAY", "YHOO")),
    new Session("dan", ImmutableSet.of("FB", "TWTR")),
    new Session("jim", ImmutableSet.of("GOOG", "TWTR", "YHOO")),
    new Session("tom", ImmutableSet.of("FB", "EBAY", "YHOO")),
    new Session("jim", ImmutableSet.of("GOOG", "TWTR", "FB"))
  };

  @Test
  public void testTickerFlow() throws Exception {
    ApplicationManager appManager = deployApplication(Tickers.class);
    FlowManager flowManager = appManager.startFlow("TickerFlow");
    StreamWriter streamWriter = appManager.getStreamWriter("sessions");

    // send all sessions to the stream
    for (Session session : SESSIONS) {
      streamWriter.send(GSON.toJson(session));
    }

    // wait for both consumer flowlets to finish processing them
    RuntimeMetrics correlatorMetrics = RuntimeStats.getFlowletMetrics("Tickers", "TickerFlow", "correlator");
    RuntimeMetrics counterMetrics = RuntimeStats.getFlowletMetrics("Tickers", "TickerFlow", "counter");
    correlatorMetrics.waitForProcessed(SESSIONS.length, 10, TimeUnit.SECONDS);
    counterMetrics.waitForProcessed(SESSIONS.length, 10, TimeUnit.SECONDS);
    Assert.assertEquals(0, correlatorMetrics.getException());
    Assert.assertEquals(0, counterMetrics.getException());

    DataSetManager<AffinityTable> affinities = getDataset("affinities");
    DataSetManager<InterestTable> interests = getDataset("interests");

    Map<String, Long> result = affinities.get().getAffinities("GOOG");
    Assert.assertEquals(4, result.size());
    Assert.assertEquals((Long)3L, result.get("YHOO"));
    Assert.assertEquals((Long)1L, result.get("EBAY"));
    Assert.assertEquals((Long)2L, result.get("TWTR"));
    Assert.assertEquals((Long)2L, result.get("FB"));

    result = interests.get().getInterests("jim");
    Assert.assertEquals(4, result.size());
    Assert.assertEquals((Long)3L, result.get("GOOG"));
    Assert.assertEquals((Long)2L, result.get("YHOO"));
    Assert.assertEquals((Long)2L, result.get("TWTR"));
    Assert.assertEquals((Long)2L, result.get("FB"));
  }
}

