package co.cask.cdap.training.tickers;

import com.google.common.collect.Maps;

import java.util.Collection;
import java.util.Map;

/**
 * A dataset that tracks user interests by counting all stock symbols from the user's sessions.
 */
public class InterestTable { // TODO how do you make this a Dataset?

  // TODO complete this constructor so that it takes a table as an embedded dataset
  public InterestTable() {
  }

  /**
   * For a given a user, record each stock symbol that this user viewed in one session.
   */
  public void addSession(String user, Collection<String> symbols) {
    // TODO increment a counter in the embedded table for each symbol
  }

  /**
   * @return a map that gives, for each symbol this user has viewed, the number of
   * sessions where he did so; or null if no interests are known for that user.
   */
  public Map<String, Long> getInterests(String user) {
    Map<String, Long> results = Maps.newHashMap();
    // TODO read the counters from the embedded tables and convert them to Long
    return results;
  }

}
