package co.cask.cdap.training.tickers;

import co.cask.cdap.api.annotation.ProcessInput;
import co.cask.cdap.api.common.Bytes;
import co.cask.cdap.api.flow.Flow;
import co.cask.cdap.api.flow.FlowSpecification;
import co.cask.cdap.api.flow.flowlet.AbstractFlowlet;
import co.cask.cdap.api.flow.flowlet.OutputEmitter;
import co.cask.cdap.api.flow.flowlet.StreamEvent;
import com.google.gson.Gson;

/**
 * A flow that computes affinities of stock symbols and user interest.
 */
public class TickerFlow extends AbstractFlow {

  @Override
  public void configureFlow() {
    setName("TickerFlow");
    setDescription("Computes affinities of stock symbols and user interest.");
    addFlowlet("parser", new SessionParser());
    addFlowlet("correlator", new AffinityCounter());
    addFlowlet("counter", new InterestCounter());
    connectStream("sessions", "parser");
    connect("parser", "correlator");
    connect("parser", "counter");
  }

  private static class SessionParser extends AbstractFlowlet {

    private static final Gson GSON = new Gson();

    private OutputEmitter<Session> out;

    @ProcessInput
    public void process(StreamEvent event) {
      Session session = GSON.fromJson(Bytes.toString(event.getBody()), Session.class);
      out.emit(session);
    }
  }

  private static class AffinityCounter extends AbstractFlowlet {

    // TODO what do you need to add here to inject the affinities datasets?

    @ProcessInput
    public void process(Session session) {
      // TODO call a method of the affinities dataset
    }
  }

  private static class InterestCounter extends AbstractFlowlet {

    // TODO what do you need to add here to inject the affinities datasets?

    @ProcessInput
    public void process(Session session) {
      // TODO call a method of the interests dataset
    }
  }
}
