package co.cask.cdap.training.tickers;

import co.cask.cdap.api.app.AbstractApplication;
import co.cask.cdap.api.data.stream.Stream;

/**
 * A simple stock ticker analytics app.
 */
public class Tickers extends AbstractApplication {

  @Override
  public void configure() {
    setName("Tickers");
    setDescription("A simple stock ticker analytics app.");
    addFlow(new TickerFlow());
    addService(new TickerService());
    addStream(new Stream("sessions"));
    // TODO create two datasets, one for interests, one for affinities
  }
}
