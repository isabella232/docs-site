package co.cask.cdap.training.tickers;

import co.cask.cdap.api.service.AbstractService;
import co.cask.cdap.api.service.http.AbstractHttpServiceHandler;
import co.cask.cdap.api.service.http.HttpServiceRequest;
import co.cask.cdap.api.service.http.HttpServiceResponder;

import java.net.HttpURLConnection;
import java.util.Map;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

/**
 * Ticker Service.
 */
public class TickerService extends AbstractService {

  @Override
  protected void configure() {
    setName("TickerService");
    addHandler(new TickerHandler());
  }

  /**
   * TickerHandler.
   */
  public static final class TickerHandler extends AbstractHttpServiceHandler {

    // TODO what do you need to add here to inject the two datasets?

    @Path("affinities/{ticker}")
    @GET
    public void getAffinities(HttpServiceRequest request, HttpServiceResponder responder,
                              @PathParam("ticker") String ticker) {
      Map<String, Long> results = null; // TODO retrieve this from affinities dataset
      if (results == null) {
        responder.sendError(HttpURLConnection.HTTP_NOT_FOUND,
                            String.format("Affinities for ticker %s not found", ticker));
      } else {
        responder.sendJson(HttpURLConnection.HTTP_OK, results);
      }
    }

    @Path("interests/{user}")
    @GET
    public void getInterests(HttpServiceRequest request, HttpServiceResponder responder,
                             @PathParam("user") String user) {
      Map<String, Long> results = null; // TODO retrieve this from interests dataset
      if (results == null) {
        responder.sendError(HttpURLConnection.HTTP_NOT_FOUND,
                            String.format("User %s not found", user));
      } else {
        responder.sendJson(HttpURLConnection.HTTP_OK, results);
      }
    }
  }
}
