package co.cask.cdap.training.tickers;

import com.google.common.collect.Maps;

import java.util.Collection;
import java.util.Map;

/**
 * A dataset that tracks affinities of symbols.
 * Affinity is a measure of how frequently two tickers occur in the same session.
 */
public class AffinityTable { // TODO how do you make this a Dataset?

  // TODO complete this constructor so that it takes a table as an embedded dataset
  public AffinityTable() {
  }

  /**
   * Record all the symbols that some user has viewed in a single session.
   */
  public void addSession(Collection<String> symbols) {
    // TODO for each pair of distinct symbols in the session, increment a counter in the embedded table
  }

  /**
   * @return all other stock symbols that appeared in the same session as this symbol. The result maps
   * each such symbol to the number of distinct session in which it co-occurred with this symbol. Return
   * null if the symbol is not known.
   */
  public Map<String, Long> getAffinities(String symbol) {
    Map<String, Long> results = Maps.newHashMap();
    // TODO read the counters from the embedded tables and convert them to Long
    return results;
  }

}
