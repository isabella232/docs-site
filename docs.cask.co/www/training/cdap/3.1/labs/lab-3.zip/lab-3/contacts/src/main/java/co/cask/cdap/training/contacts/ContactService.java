package co.cask.cdap.training.contacts;

import co.cask.cdap.api.common.Bytes;
import co.cask.cdap.api.service.AbstractService;
import co.cask.cdap.api.service.http.AbstractHttpServiceHandler;
import co.cask.cdap.api.service.http.HttpServiceRequest;
import co.cask.cdap.api.service.http.HttpServiceResponder;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.io.ByteStreams;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import org.apache.twill.filesystem.Location;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

/**
 * A {@link co.cask.cdap.api.service.Service} to upload and retrieve contacts and their pictures.
 */
public final class ContactService extends AbstractService {

  public static final String SERVICE_NAME = "ContactService";

  @Override
  protected void configure() {
    setName(SERVICE_NAME);
    setDescription("Service to upload and retrieve contacts and their pictures.");
    addHandler(new ContactHandler());
  }

  /**
   * Contact Service handler.
   */
  public static final class ContactHandler extends AbstractHttpServiceHandler {

    static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // TODO what do you need to do use the two datasets in this handler?
    
    @GET
    @Path("contacts/{nick}")
    public void readContact(HttpServiceRequest request, HttpServiceResponder responder,
                            @PathParam("nick") String nickName) {

      // read the contact from the contacts table
      Contact contact = null; // TODO replace null with read from table
      if (contact == null) {
        responder.sendStatus(404);
        return;
      }
      // do not reveal path to outside, it is an internal detail
      contact.setPicturePath(null);
      responder.sendJson(200, contact);
    }

    @PUT
    @Path("contacts/{nick}")
    public void writeContact(HttpServiceRequest request, HttpServiceResponder responder,
                             @PathParam("nick") String nickName) {

      Contact contact;
      try {
        contact = contactFromRequest(request);
      } catch (JsonSyntaxException e) {
        responder.sendError(400, "Bad input: " + e.getMessage());
        return;
      }
      if (contact.getPicturePath() != null) {
        responder.sendError(400, "Bad input: picturePath must not be specified");
        return;
      }
      // TODO write contact to dataset
      responder.sendStatus(200);
    }

    @GET
    @Path("contacts/{nick}/picture")
    public void readPicture(HttpServiceRequest request, HttpServiceResponder responder,
                            @PathParam("nick") String nickName) {

      Contact contact = null; // TODO replace null with read from table
      if (contact == null || contact.getPicturePath() == null) {
        responder.sendStatus(404);
        return;
      }
      String picturePath = contact.getPicturePath();
      Location location = null; // TODO obtain a location from the "pictures" file set
      ByteBuffer content;
      try {
        content = readInputStream(location.getInputStream());
      } catch (IOException e) {
        responder.sendError(500, "Error reading picture file: " + e.getMessage());
        return;
      }
      responder.send(200, content, "application/octet-stream", ImmutableMultimap.<String, String>of());
    }

    @PUT
    @Path("contacts/{nick}/picture")
    public void writePicture(HttpServiceRequest request, HttpServiceResponder responder,
                             @PathParam("nick") String nickName) {

      Contact contact = null; // TODO replace null with read from table
      if (contact == null) {
        responder.sendStatus(404);
        return;
      }
      String picturePath = contact.getPicturePath();
      if (picturePath != null) {
        try {
          // TODO delete the existing file

        } catch (Exception e) {
          responder.sendError(500, "Error deleting existing picture: " + e.getMessage());
          return;
        }
      }
      picturePath = "pic." + nickName;
      Location location = null; // TODO obtain a location from the "pictures" file set
      try {
        writeRequestToOutputStream(request, location.getOutputStream());
      } catch (IOException e) {
        responder.sendError(400, "Error writing picture file: " + e.getMessage());
        return;
      }
      contact.setPicturePath(picturePath);
      // TODO write contact to dataset
      responder.sendStatus(200);
    }

    /**
     * Helper method to parse the content of a request into a Contact.
     * @throws JsonSyntaxException is the content is not valid Json
     */
    private static Contact contactFromRequest(HttpServiceRequest request) throws JsonSyntaxException {
      String json = Bytes.toString(request.getContent());
      Contact contact = GSON.fromJson(json, Contact.class);
      if (!contact.isValid()) {
        throw new JsonSyntaxException("Incomplete object: Name must be present");
      }
      return contact;
    }

    /**
     * Helper method to read all content from an input stream into a byte buffer.
     * @throws IOException if something goes wrong
     */
    private static ByteBuffer readInputStream(InputStream inputStream) throws IOException {
      return ByteBuffer.wrap(ByteStreams.toByteArray(inputStream));

    }

    /**
     * Helper to write a the content of a request to an output stream.
     * @throws IOException if something goes wrong
     */
    private static void writeRequestToOutputStream(HttpServiceRequest request,
                                                   OutputStream outputStream) throws IOException {
      WritableByteChannel channel = Channels.newChannel(outputStream);
      try {
        channel.write(request.getContent());
      } finally {
        channel.close();
      }
    }
  }
}
