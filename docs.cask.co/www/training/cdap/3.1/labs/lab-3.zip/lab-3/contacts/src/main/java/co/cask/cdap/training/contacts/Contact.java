package co.cask.cdap.training.contacts;

/**
 * Represents a single contact.
 */
public class Contact {
  private String name;
  private String address;
  private String phone;
  private String picturePath;

  public Contact(String name, String address, String phone) {
    this.name = name;
    this.address = address;
    this.phone = phone;
  }

  public String getName() {
    return name;
  }

  public String getAddress() {
    return address;
  }

  public String getPhone() {
    return phone;
  }

  public String getPicturePath() {
    return picturePath;
  }

  public void setPicturePath(String picturePath) {
    this.picturePath = picturePath;
  }

  /**
   * This is useful after deserializing from JSON, which sets absent fields to null.
   * So it can happen that the contact does not have a name.
   */
  public boolean isValid() {
    return name != null;
  }
}
