package co.cask.cdap.training.mapreduce;

import co.cask.cdap.api.annotation.UseDataSet;
import co.cask.cdap.api.common.Bytes;
import co.cask.cdap.api.dataset.lib.CloseableIterator;
import co.cask.cdap.api.dataset.lib.KeyValue;
import co.cask.cdap.api.dataset.lib.ObjectStore;
import co.cask.cdap.api.service.AbstractService;
import co.cask.cdap.api.service.http.AbstractHttpServiceHandler;
import co.cask.cdap.api.service.http.HttpServiceRequest;
import co.cask.cdap.api.service.http.HttpServiceResponder;
import com.google.common.collect.Lists;

import java.util.List;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

/**
 * Service to retrieve results of top-N stock symbols.
 */
public class TickerService extends AbstractService {


  @Override
  protected void configure() {
    setName("TopClientsService");
    setDescription("Service to get top ticker symbols");
    addHandler(new ResultsHandler());
  }

  public static class ResultsHandler extends AbstractHttpServiceHandler {

    @UseDataSet(Tickers.DATASET_NAME)
    private ObjectStore<List<TickerSymbolCount>> topTickers;

    /**
     * Handler to retrieve the results of top-N symbols. The handler expects an optional start and end time.
     * If they are not specified the results for last 1 hr are fetched.
     */
    @GET
    @Path("/results")
    public void getResults(HttpServiceRequest request, HttpServiceResponder responder,
                           @QueryParam("start") String start, @QueryParam("end") String end) {

      long currentTimeSecs = System.currentTimeMillis() / 1000;

      long startTime = start == null || start.isEmpty() ? currentTimeSecs - 3600 : Long.parseLong(start);
      long endTime = end == null || end.isEmpty() ? currentTimeSecs : Long.parseLong(end);


      CloseableIterator<KeyValue<byte[], List<TickerSymbolCount>>> iterator = topTickers.scan(Bytes.toBytes(startTime),
                                                                                   Bytes.toBytes(endTime));

      List<Result> result = Lists.newArrayList();
      while (iterator.hasNext()) {
        KeyValue<byte[], List<TickerSymbolCount>> keyval = iterator.next();
        result.add(new Result(Bytes.toLong(keyval.getKey()), keyval.getValue()));
      }

      if (result.isEmpty()) {
        responder.sendError(404, "Result not found");
      } else {
        responder.sendJson(200, result);
      }
    }
  }

  // pojo for results returned from services
  private static final class Result {
    private Result(long time, List<TickerSymbolCount> tickers) {
      this.time = time;
      this.tickers = tickers;
    }

    private long time;
    private List<TickerSymbolCount> tickers;
  }

}
