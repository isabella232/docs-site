package co.cask.cdap.training.mapreduce;

import java.util.Set;

/**
 * Represents a user session, with the user's name and a list of all stock symbols viewed.
 */
public class Session {

  private String user;
  private Set<String> symbols;

  public Session(String user, Set<String> symbols) {
    this.user = user;
    this.symbols = symbols;
  }

  public String getUser() {
    return user;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public Set<String> getSymbols() {
    return symbols;
  }

  public void setSymbols(Set<String> symbols) {
    this.symbols = symbols;
  }
}