package co.cask.cdap.training.mapreduce;

import com.google.gson.Gson;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

/**
 * Mapper that gets StreamEvent, de-serializes into Session and maps Symbol as the key and symbol count as the value.
 */
public class TickerMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
  private static final IntWritable OUTPUT_VALUE = new IntWritable(1);
  private static final Gson GSON = new Gson();
  @Override
  public void map(LongWritable key, Text value, Context context)
              throws IOException, InterruptedException {
    // The body of the stream event is contained in the Text value
    String streamBody = value.toString();
    if (streamBody != null  && !streamBody.isEmpty()) {
      // TODO: Deserialize streamBody into Session
      // TODO: For all symbols in Session emity Symbol as key and OUTPUT_VALUE
     }
  }
}
