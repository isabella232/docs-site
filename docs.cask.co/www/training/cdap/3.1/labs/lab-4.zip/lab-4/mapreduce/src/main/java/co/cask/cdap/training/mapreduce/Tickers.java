package co.cask.cdap.training.mapreduce;

import co.cask.cdap.api.app.AbstractApplication;
import co.cask.cdap.api.data.stream.Stream;
import co.cask.cdap.api.dataset.DatasetProperties;
import co.cask.cdap.api.dataset.lib.ObjectStore;
import co.cask.cdap.api.dataset.lib.ObjectStores;
import co.cask.cdap.api.dataset.table.Table;
import co.cask.cdap.api.schedule.Schedules;
import com.google.common.base.Throwables;
import com.google.inject.util.Types;

/**
 * Tickers MapReduce example.
 */
public class Tickers extends AbstractApplication {

  public static final String DATASET_NAME = "topTickers";

  @Override
  public void configure() {
    setName("Tickers");
    setDescription("A simple stock ticker analytics app.");
    addStream(new Stream("tickers"));
    addService(new TickerService());
    // TODO: Add Mapreduce
    // TODO: Add workflow
    // TODO: Add schedule to workflow
    try {

      DatasetProperties props = ObjectStores.objectStoreProperties(Types.listOf(TickerSymbolCount.class),
                                                                   DatasetProperties.EMPTY);
      createDataset(DATASET_NAME, ObjectStore.class, props);
    } catch (Throwable th) {
      throw Throwables.propagate(th);
    }
  }
}
