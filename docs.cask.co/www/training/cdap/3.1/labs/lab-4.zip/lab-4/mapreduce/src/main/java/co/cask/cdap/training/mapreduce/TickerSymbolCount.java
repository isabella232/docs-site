package co.cask.cdap.training.mapreduce;

/**
 * Holds ticker symbol and count pair.
 */
public class TickerSymbolCount implements Comparable<TickerSymbolCount> {
  private final String symbol;
  private final int count;

  public TickerSymbolCount(String symbol, int count) {
    this.symbol = symbol;
    this.count = count;
  }

  public String getSymbol() {
    return symbol;
  }

  public int getCount() {
    return count;
  }

  @Override
  public int compareTo(TickerSymbolCount clientCount) {
    if (clientCount.count == count) {
      return 0;
    } else {
      return count > clientCount.count ? -1 : 1;
    }
  }
}