package co.cask.cdap.training.mapreduce;

import co.cask.cdap.api.data.stream.StreamBatchReadable;
import co.cask.cdap.api.mapreduce.AbstractMapReduce;
import co.cask.cdap.api.mapreduce.MapReduceContext;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;

import java.util.concurrent.TimeUnit;

/**
 * MapReduce job that creates top-N ticker symbols by Count.
 */
public class TopTickerMapReduce extends AbstractMapReduce {

  @Override
  public void configure() {
    setName("TopTickerMapReduce");
    setDescription("MapReduce program that computes top 10 tickers in the last 1 hour");
    // TODO: Set output Dataset
  }

  @Override
  public void beforeSubmit(MapReduceContext context) throws Exception {

    // Get the Hadoop job context, set Mapper, reducer and combiner.
    Job job = (Job) context.getHadoopJob();

    // TODO: Set Mapoutput key
    // TODO: Set Mapoutput value
    // TODO: Set Mapper, reducer and combiner


    // Number of reducer set to 1 to compute topN in a single reducer.
    job.setNumReduceTasks(1);


    // Read events from last 60 minutes as input to the mapper.
    final long endTime = context.getLogicalStartTime();
    final long startTime = endTime - TimeUnit.MINUTES.toMillis(60);
    // TODO: Set StreamBatchReadable
    // StreamBatchReadable.useStreamInput();
  }
}
