package co.cask.cdap.training.mapreduce;

import co.cask.cdap.api.common.Bytes;
import com.google.common.collect.Lists;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.List;
import java.util.PriorityQueue;


/**
 * Reducer to compute topN symbols by Count.
 */
public class TopNTickerReducer extends Reducer<Text, IntWritable, byte[], List<TickerSymbolCount>> {


  private static final int COUNT = 10;
  private static final PriorityQueue<TickerSymbolCount> priorityQueue = new PriorityQueue<TickerSymbolCount>(COUNT);

  @Override
  protected void reduce(Text key, Iterable<IntWritable> values, Context context)
    throws IOException, InterruptedException {
    //TODO: For each Key: Symbol, aggregate the Value: Count.

    // TODO: Add the result to priorityQueue

  }

  @Override
  protected void cleanup(Context context) throws IOException, InterruptedException {
    // Write topN results in reduce output. Since the "topN" (ObjectStore) Dataset is used as output the entries
    // will be written to the Dataset without any additional effort.
    List<TickerSymbolCount> topNResults = Lists.newArrayList();
   // TODO: Read all the entries from Priority Queue into topNresults.
    long timestampSecs = System.currentTimeMillis() / 1000;
   // TOOD: Write result to context
  }
}

