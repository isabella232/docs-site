package co.cask.cdap.training.mapreduce;

import co.cask.cdap.api.workflow.AbstractWorkflow;

/**
 * Ticker Workflow to run the mapreduce job every hour.
 */
public class TickerWorkflow extends AbstractWorkflow {
  @Override
  protected void configure() {
    setName("TickerWorkflow");
    setDescription("Workflow to run the TopTicker every hour");
   //TODO: Add MapReduce
  }
}