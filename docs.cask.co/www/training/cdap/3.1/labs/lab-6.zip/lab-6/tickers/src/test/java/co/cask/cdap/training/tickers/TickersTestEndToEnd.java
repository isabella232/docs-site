package co.cask.cdap.training.tickers;

import co.cask.cdap.api.metrics.RuntimeMetrics;
import co.cask.cdap.test.ApplicationManager;
import co.cask.cdap.test.FlowManager;
import co.cask.cdap.test.RuntimeStats;
import co.cask.cdap.test.ServiceManager;
import co.cask.cdap.test.StreamWriter;
import co.cask.cdap.test.TestBase;
import com.google.common.base.Charsets;
import com.google.common.collect.ImmutableSet;
import com.google.common.io.ByteStreams;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.junit.Assert;
import org.junit.Test;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Test End to End
 */
public class TickersTestEndToEnd extends TestBase {

  private static final Gson GSON = new Gson();

  private static final Session[] SESSIONS = {
    new Session("jim", ImmutableSet.of("GOOG", "YHOO", "FB")),
    new Session("tom", ImmutableSet.of("GOOG", "EBAY", "YHOO")),
    new Session("dan", ImmutableSet.of("FB", "TWTR")),
    new Session("jim", ImmutableSet.of("GOOG", "TWTR", "YHOO")),
    new Session("tom", ImmutableSet.of("FB", "EBAY", "YHOO")),
    new Session("jim", ImmutableSet.of("GOOG", "TWTR", "FB"))
  };

  @Test
  public void testTickerFlow() throws Exception {
   
    // TODO: Deploy the application
    // TODO: Start flow
    // TODO: Get StreamWriter
    // send all sessions to the stream
    for (Session session : SESSIONS) {
      // TODO: Send data to stream
      // streamWriter.send(GSON.toJson(session));
    }

    // wait for both consumer flowlets to finish processing them
    RuntimeMetrics correlatorMetrics = RuntimeStats.getFlowletMetrics("Tickers", "TickerFlow", "correlator");
    RuntimeMetrics counterMetrics = RuntimeStats.getFlowletMetrics("Tickers", "TickerFlow", "counter");
    correlatorMetrics.waitForProcessed(SESSIONS.length, 10, TimeUnit.SECONDS);
    counterMetrics.waitForProcessed(SESSIONS.length, 10, TimeUnit.SECONDS);
    Assert.assertEquals(0, correlatorMetrics.getException());
    Assert.assertEquals(0, counterMetrics.getException());

    // TODO: Start service
    
    // Validate results
    String path = "affinities/GOOG";
    URL url = new URL(serviceManager.getServiceURL(15, TimeUnit.SECONDS), path);
    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    Assert.assertEquals(HttpURLConnection.HTTP_OK, conn.getResponseCode());
    String result = new String(ByteStreams.toByteArray(conn.getInputStream()), Charsets.UTF_8);
    Map<String, Long> affinityCounts = GSON.fromJson(result, new TypeToken<Map<String, Long>>() {}.getType());
    Assert.assertEquals(4, affinityCounts.size());
    Assert.assertEquals(3L, (long) affinityCounts.get("YHOO"));
    Assert.assertEquals(1L, (long) affinityCounts.get("EBAY"));
    Assert.assertEquals(2L, (long) affinityCounts.get("FB"));
    Assert.assertEquals(2L, (long) affinityCounts.get("TWTR"));

    flowManager.stop();
    serviceManager.stop();
  }
}
