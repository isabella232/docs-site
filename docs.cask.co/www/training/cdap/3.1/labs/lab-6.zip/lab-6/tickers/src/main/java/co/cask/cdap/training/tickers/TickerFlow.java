package co.cask.cdap.training.tickers;

import co.cask.cdap.api.annotation.ProcessInput;
import co.cask.cdap.api.annotation.UseDataSet;
import co.cask.cdap.api.common.Bytes;
import co.cask.cdap.api.dataset.table.Increment;
import co.cask.cdap.api.dataset.table.Table;
import co.cask.cdap.api.flow.AbstractFlow;
import co.cask.cdap.api.flow.flowlet.AbstractFlowlet;
import co.cask.cdap.api.flow.flowlet.OutputEmitter;
import co.cask.cdap.api.flow.flowlet.StreamEvent;
import com.google.gson.Gson;

/**
 * A flow that computes affinities of stock symbols and user interest.
 */
public class TickerFlow extends AbstractFlow {

  @Override
  public void configureFlow() {
    setName("TickerFlow");
    setDescription("Computes affinities of stock symbols and user interest.");
    addFlowlet("parser", new SessionParser());
    addFlowlet("correlator", new AffinityCounter());
    addFlowlet("counter", new InterestCounter());
    connectStream("sessions", "parser");
    connect("parser", "correlator");
    connect("parser", "counter");
  }

  private static class SessionParser extends AbstractFlowlet {

    private static final Gson GSON = new Gson();

    private OutputEmitter<Session> out;

    @ProcessInput
    public void process(StreamEvent event) {
      Session session = GSON.fromJson(Bytes.toString(event.getBody()), Session.class);
      out.emit(session);
    }
  }

  private static class AffinityCounter extends AbstractFlowlet {

    @UseDataSet("affinities")
    private Table affinities;

    @ProcessInput
    public void process(Session session) {
      for (String symbol : session.getSymbols()) {
        Increment increment = new Increment(symbol);
        for (String other : session.getSymbols()) {
          if (!symbol.equals(other)) {
            increment.add(other, 1L);
          }
        }
        affinities.increment(increment);
      }
    }
  }

  private static class InterestCounter extends AbstractFlowlet {

    @UseDataSet("interests")
    private Table interests;

    @ProcessInput
    public void process(Session session) {
      Increment increment = new Increment(session.getUser());
      for (String symbol : session.getSymbols()) {
        increment.add(symbol, 1L);
      }
      interests.increment(increment);
    }
  }
}
