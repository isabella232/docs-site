package co.cask.cdap.training.tickers;

import co.cask.cdap.api.app.AbstractApplication;
import co.cask.cdap.api.data.stream.Stream;
import co.cask.cdap.api.dataset.table.Table;

/**
 * A simple stock ticker analytics app.
 */
public class Tickers extends AbstractApplication {

  @Override
  public void configure() {
    setName("Tickers");
    setDescription("A simple stock ticker analytics app.");

    //TODO: Add flow
    addStream(new Stream("sessions"));

    // TODO: Create Datasets
    addService(new TickerService());
  }
}
