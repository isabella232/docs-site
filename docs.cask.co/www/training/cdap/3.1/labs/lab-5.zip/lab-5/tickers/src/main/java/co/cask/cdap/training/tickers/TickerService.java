package co.cask.cdap.training.tickers;

import co.cask.cdap.api.annotation.UseDataSet;
import co.cask.cdap.api.common.Bytes;
import co.cask.cdap.api.dataset.table.Get;
import co.cask.cdap.api.dataset.table.Increment;
import co.cask.cdap.api.dataset.table.Row;
import co.cask.cdap.api.dataset.table.Table;
import co.cask.cdap.api.service.AbstractService;
import co.cask.cdap.api.service.http.AbstractHttpServiceHandler;
import co.cask.cdap.api.service.http.HttpServiceRequest;
import co.cask.cdap.api.service.http.HttpServiceResponder;
import com.google.common.base.Charsets;
import com.google.common.collect.Maps;
import com.google.gson.Gson;

import java.net.HttpURLConnection;
import java.util.Map;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

/**
 * Ticker Service
 */
public class TickerService extends AbstractService {

  @Override
  protected void configure() {
    setName("TickerService");
    addHandler(new TickerHandler());
  }

  /**
   * TickerHandler.
   */
  public static final class TickerHandler extends AbstractHttpServiceHandler {

    @UseDataSet("affinities")
    private Table affinities;

    @UseDataSet("interests")
    private Table interests;

    private static final Gson GSON = new Gson();


    @Path("affinities/{ticker}")
    @GET
    public void getAffinity(HttpServiceRequest request, HttpServiceResponder responder,
                            @PathParam("ticker") String ticker) {

      Row row = affinities.get(new Get(ticker));
      if (row == null) {
        responder.sendError(HttpURLConnection.HTTP_NOT_FOUND,
                            String.format("Affinities for ticker %s not found", ticker));
      } else {
        Map<byte[], byte[]> values = row.getColumns();
        Map<String, Long> results = Maps.newHashMap();
        for (Map.Entry<byte[], byte[]> entry : values.entrySet()) {
          results.put(Bytes.toString(entry.getKey()), Bytes.toLong(entry.getValue()));
        }
        responder.sendJson(HttpURLConnection.HTTP_OK, results);
      }
    }

    @Path("interests/{user}")
    @GET
    public void getInterests(HttpServiceRequest request, HttpServiceResponder responder,
                             @PathParam("user") String user) {

      Row row = interests.get(new Get(user));
      if (row == null) {
        responder.sendError(HttpURLConnection.HTTP_NOT_FOUND,
                            String.format("User  %s not found", user));
      } else {
        Map<byte[], byte[]> values = row.getColumns();
        Map<String, Long> results = Maps.newHashMap();
        for (Map.Entry<byte[], byte[]> entry : values.entrySet()) {
          results.put(Bytes.toString(entry.getKey()), Bytes.toLong(entry.getValue()));
        }
        responder.sendJson(HttpURLConnection.HTTP_OK, results);
      }
    }

    @Path("sessions")
    @POST
    public void writeSession(HttpServiceRequest request, HttpServiceResponder responder) {
      String data = Charsets.UTF_8.decode(request.getContent()).toString();
      Session session = GSON.fromJson(data, Session.class);
      updateAffinity(session);
      responder.sendStatus(HttpURLConnection.HTTP_OK);
    }

    private void updateAffinity(Session session) {
      for (String symbol : session.getSymbols()) {
        Increment increment = new Increment(symbol);
        for (String other : session.getSymbols()) {
          if (!symbol.equals(other)) {
            increment.add(other, 1L);
          }
        }
        affinities.increment(increment);
      }
    }
  }
}
