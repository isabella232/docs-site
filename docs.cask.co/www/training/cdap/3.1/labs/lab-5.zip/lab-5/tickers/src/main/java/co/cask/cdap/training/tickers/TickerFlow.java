package co.cask.cdap.training.tickers;

import co.cask.cdap.api.annotation.ProcessInput;
import co.cask.cdap.api.dataset.table.Increment;
import co.cask.cdap.api.flow.AbstractFlow;
import co.cask.cdap.api.flow.flowlet.AbstractFlowlet;
import co.cask.cdap.api.flow.flowlet.StreamEvent;
import com.google.gson.Gson;

/**
 * A flow that computes affinities of stock symbols and user interest.
 */
public class TickerFlow extends AbstractFlow {

  @Override
  public void configureFlow() {
      setName("TickerFlow");
      setDescription("Computes affinities of stock symbols and user interest.");
      addFlowlet("parser", new SessionParser());
      addFlowlet("correlator", new AffinityCounter());
      addFlowlet("counter", new InterestCounter());
      connectStream("sessions", "parser");
      connect("parser", "correlator");
      connect("parser", "counter");
  }

  private static class SessionParser extends AbstractFlowlet {

    private static final Gson GSON = new Gson();

    // TODO: Declare Output Emitter

    @ProcessInput
    public void process(StreamEvent event) {
      // TODO: Emit session
    }
  }

  private static class AffinityCounter extends AbstractFlowlet {

    // TODO: inject dataset

    @ProcessInput
    public void process(Session session) {
      for (String symbol : session.getSymbols()) {
        Increment increment = null; // TODO: create an Increment for this symbol
        // TODO: Fill in the Increment for every other symbol in the session
        // TODO: Use the injected dataset to execute the Increment
      }
    }
  }

  private static class InterestCounter extends AbstractFlowlet {

    // TODO: inject dataset

    @ProcessInput
    public void process(Session session) {
      Increment increment = null; // TODO: Create an Imcrement for the session's user
      // TODO: Fill in the Increment for every symbol in the session
      // TODO: Use the injected dataset to execute the Increment
    }
  }
}
